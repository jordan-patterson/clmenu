from clmenu.clmenu import Menu
from clmenu.clmenu import printLogo
from clmenu.clmenu import getch